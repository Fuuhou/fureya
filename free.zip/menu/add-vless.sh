#!/bin/bash

clear
source /var/lib/xdxl/ipvps.conf
domain=$(cat /etc/xray/domain)

until [[ $user =~ ^[a-zA-Z0-9_]+$ && ${CLIENT_EXISTS} == '0' ]]; do
echo -e "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo " New VLESS Account"
		read -rp "Username: " -e user
                read -rp "Limit IP: " -e limit
		CLIENT_EXISTS=$(grep -w $user /etc/xray/config.json | wc -l)

		if [[ ${CLIENT_EXISTS} == '1' ]]; then
clear
		echo -e "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
			echo ""
			echo "Username Already Exist!"
			echo ""
			read -n 1 -s -r -p "Press any key to back on menu"
			menu-vless
		fi
	done

uuid=$(cat /proc/sys/kernel/random/uuid)
read -p "masa aktif : " masaaktif
exp=`date -d "$masaaktif days" +"%Y-%m-%d"`
sed -i '/#vless$/a\#& '"$user $exp"'\
},{"id": "'""$uuid""'","email": "'""$user""'"' /etc/xray/config.json
sed -i '/#vlessgrpc$/a\#& '"$user $exp"'\
},{"id": "'""$uuid""'","email": "'""$user""'"' /etc/xray/config.json
vlesslink1="vless://${uuid}@${domain}:$tls?path=/vless&security=tls&encryption=none&type=ws#${user}"
vlesslink2="vless://${uuid}@${domain}:$none?path=/vless&encryption=none&type=ws#${user}"
vlesslink3="vless://${uuid}@${domain}:$tls?mode=gun&security=tls&encryption=none&type=grpc&serviceName=vless-grpc&sni=${domain}#${user}"
systemctl restart xray
clear
echo -e "━━━━━━━━━━━━━━━━━━"
echo -e "〚 VLESS ACCOUNT 〛"
echo -e "━━━━━━━━━━━━━━━━━━"
echo -e "Username      : ${user}"
echo -e "Host/IP       : ${domain}"
echo -e "Port None-TLS : 80, 8080"
echo -e "Port TLS-GRPC : 443, 8443"
echo -e "Uuid          : ${uuid}"
echo -e "Network       : ws-grpc"
echo -e "Path          : /vless"
echo -e "ServiceName   : vless"
echo -e "━━━━━━━━━━━━━━━━━━"
echo -e "Link TLS : "
echo -e "${vlesslink1}"
echo -e "━━━━━━━━━━━━━━━━━━"
echo -e "Link None-TLS : "
echo -e "${vlesslink2}"
echo -e "━━━━━━━━━━━━━━━━━━"
echo -e "Link GRPC : "
echo -e "${vlesslink3}"
echo -e "━━━━━━━━━━━━━━━━━━"
echo -e "EXPIRED: $exp"
echo ""
